.inputCheck.diffGGM <- function(S1, S2, n1, n2, lambda, Uequal=FALSE, gMin=10^(-5), llDiff=10^(-5), nInit=100, verbose=FALSE, nStepsU=20){
	########################################################################################################################
	# check inputs for the function diffGGM
	########################################################################################################################

	# input checks
	if (as.character(class(S1)) != "matrix"){ stop("Input (S1) is of wrong class.") }
	if (!isSymmetric(S1)){ stop("Input (S1) not symmetric.") }
	if (as.character(class(S2)) != "matrix"){ stop("Input (S2) is of wrong class.") }
	if (!isSymmetric(S2)){ stop("Input (S2) not symmetric.") }
	if (nrow(S1) != nrow(S2)){ stop("Dimensions of input (S1 and S2) do not match.") } 
	if (ncol(S1) != ncol(S2)){ stop("Dimensions of input (S1 and S2) do not match.") } 
	if (as.character(class(n1)) != "numeric" & as.character(class(n1)) != "integer"){ stop("Input (n1) is of wrong class.") }
	if (length(n1) != 1){ stop("Input (n1) is of wrong length.") }
	if (is.na(n1)){ stop("Input (n1) is not a positive integer.") }
	if (n1 <= 0){ stop("Input (n1) is not a positive integer.") }
	if (n1 %% 1 != 0){ stop("Input (n1) is not a positive integer.") }
	if (as.character(class(n2)) != "numeric" & as.character(class(n2)) != "integer"){ stop("Input (n1) is of wrong class.") }
	if (length(n2) != 1){ stop("Input (n2) is of wrong length.") }
	if (is.na(n2)){ stop("Input (n2) is not a positive integer.") }
	if (n2 <= 0){ stop("Input (n2) is not a positive integer.") }
	if (n2 %% 1 != 0){ stop("Input (n2) is not a positive integer.") }
	if (as.character(class(lambda)) != "numeric"){ stop("Input (lambda) is of wrong class.") }
	if (length(lambda) != 1){ stop("Input (lambda) is of wrong length.") }
	if (is.na(lambda)){ stop("Input (lambda) is not a positive number.") }
	if (lambda <= 0){ stop("Input (lambda) is not a positive number.") }
	if (as.character(class(Uequal)) != "logical"){ stop("Input (Uequal) is of wrong class.") }
	if (as.character(class(gMin)) != "numeric"){ stop("Input (gMin) is of wrong class.") }
	if (length(gMin) != 1){ stop("Input (gMin) is of wrong length.") }
	if (is.na(gMin)){ stop("Input (gMin) is not a positive number.") }
	if (gMin <= 0){ stop("Input (gMin) is not a positive number.") }
	if (gMin > 1){ stop("Input (gMin) not in interval (0,1).") }
	if (as.character(class(llDiff)) != "numeric"){ stop("Input (llDiff) is of wrong class.") }
	if (length(llDiff) != 1){ stop("Input (llDiff) is of wrong length.") }
	if (is.na(llDiff)){ stop("Input (llDiff) is not a positive number.") }
	if (llDiff <= 0){ stop("Input (llDiff) is not a positive number.") }
	if (as.character(class(nInit)) != "numeric" & as.character(class(nInit)) != "integer"){ stop("Input (nInit) is of wrong class.") }
	if (length(nInit) != 1){ stop("Input (nInit) is of wrong length.") }
	if (is.na(nInit)){ stop("Input (nInit) is not a positive integer.") }
	if (nInit < 0){ stop("Input (nInit) is not a positive integer.") }
	if (nInit %% 1 != 0){ stop("Input (nInit) is not a positive integer.") }
	if (as.character(class(verbose)) != "logical"){ stop("Input (verbose) is of wrong class.") }

}

optPenalty.diffGGMnull <- function(Y1, Y2, lambdaMin, lambdaMax, lambdaInit=(lambdaMin+lambdaMax)/2, llDiff=10^(-5), nInit=100, nStepsU=10){
       optLambda <- optim(lambdaInit, .cvlDiffGGMnull, method="Brent", lower=lambdaMin, upper=lambdaMax, Y1=Y1, Y2=Y2, llDiff=llDiff, nInit=nInit, nStepsU=nStepsU)$par
       return(optLambda)
}


.estGamma <- function(Ps, S2t, gMin){ 
	########################################################################################################################
	# solve estimating equation for gamma (the diluation parameter) 
	########################################################################################################################

	lValue <- .armaGammaEstEquation(gMin, Ps, S2t)  
	rValue <- .armaGammaEstEquation(1-gMin, Ps, S2t)
	if ((lValue < 0 & rValue > 0) | (lValue > 0 & rValue < 0)){
		gamma <- uniroot(.armaGammaEstEquation, c(gMin, 1-gMin), Ps=Ps, S2t=S2t)$root
	} else {
		gamma <- which.min(c(abs(lValue), abs(rValue))) - 1
		if (gamma == 0){ gamma <- gMin } else { gamma <- 1 - gMin }
	}
	return(gamma)
} 


diffGGMml <- function(S1, S2, n1, n2, lambda, Uequal=FALSE, gMin=10^(-5), llDiff=10^(-5), nInit=100, verbose=FALSE, nStepsU=10){
	########################################################################################################################
	# penalized maximum likelihood fit of a GGM from two-sample data. Both samples share a
	# partial correlation matrix, which is diluted in the second sample.
	########################################################################################################################

	# input checks
	if (as.character(class(S1)) != "matrix"){ stop("Input (S1) is of wrong class.") }
	if (!isSymmetric(S1)){ stop("Input (S1) not symmetric.") }
	if (as.character(class(S2)) != "matrix"){ stop("Input (S2) is of wrong class.") }
	if (!isSymmetric(S2)){ stop("Input (S2) not symmetric.") }
	if (nrow(S1) != nrow(S2)){ stop("Dimensions of input (S1 and S2) do not match.") } 
	if (ncol(S1) != ncol(S2)){ stop("Dimensions of input (S1 and S2) do not match.") } 
	if (as.character(class(n1)) != "numeric" & as.character(class(n1)) != "integer"){ stop("Input (n1) is of wrong class.") }
	if (length(n1) != 1){ stop("Input (n1) is of wrong length.") }
	if (is.na(n1)){ stop("Input (n1) is not a positive integer.") }
	if (n1 <= 0){ stop("Input (n1) is not a positive integer.") }
	if (n1 %% 1 != 0){ stop("Input (n1) is not a positive integer.") }
	if (as.character(class(n2)) != "numeric" & as.character(class(n2)) != "integer"){ stop("Input (n1) is of wrong class.") }
	if (length(n2) != 1){ stop("Input (n2) is of wrong length.") }
	if (is.na(n2)){ stop("Input (n2) is not a positive integer.") }
	if (n2 <= 0){ stop("Input (n2) is not a positive integer.") }
	if (n2 %% 1 != 0){ stop("Input (n2) is not a positive integer.") }
	if (as.character(class(lambda)) != "numeric"){ stop("Input (lambda) is of wrong class.") }
	if (length(lambda) != 1){ stop("Input (lambda) is of wrong length.") }
	if (is.na(lambda)){ stop("Input (lambda) is not a positive number.") }
	if (lambda <= 0){ stop("Input (lambda) is not a positive number.") }
	if (as.character(class(Uequal)) != "logical"){ stop("Input (Uequal) is of wrong class.") }
	if (as.character(class(gMin)) != "numeric"){ stop("Input (gMin) is of wrong class.") }
	if (length(gMin) != 1){ stop("Input (gMin) is of wrong length.") }
	if (is.na(gMin)){ stop("Input (gMin) is not a positive number.") }
	if (gMin <= 0){ stop("Input (gMin) is not a positive number.") }
	if (gMin > 1){ stop("Input (gMin) not in interval (0,1).") }
	if (as.character(class(llDiff)) != "numeric"){ stop("Input (llDiff) is of wrong class.") }
	if (length(llDiff) != 1){ stop("Input (llDiff) is of wrong length.") }
	if (is.na(llDiff)){ stop("Input (llDiff) is not a positive number.") }
	if (llDiff <= 0){ stop("Input (llDiff) is not a positive number.") }
	if (as.character(class(nInit)) != "numeric" & as.character(class(nInit)) != "integer"){ stop("Input (nInit) is of wrong class.") }
	if (length(nInit) != 1){ stop("Input (nInit) is of wrong length.") }
	if (is.na(nInit)){ stop("Input (nInit) is not a positive integer.") }
	if (nInit < 0){ stop("Input (nInit) is not a positive integer.") }
	if (nInit %% 1 != 0){ stop("Input (nInit) is not a positive integer.") }
	if (as.character(class(verbose)) != "logical"){ stop("Input (verbose) is of wrong class.") }

	# number of genes and sample proportions
	p <- nrow(S1)
	p1 <- n1 / (n1 + n2)
	p2 <- n2 / (n1 + n2)

	# initial estimate
	PsHat <- .armaEstPsUnstructured(S1, S2, p1, p2, 1-gMin, log(exp(lambda) + .1))
	Uhats <- .armaEstUs(PsHat$Ps, S1, S2, n1, n2, gamma=1-gMin, Uequal=Uequal)
	U1hat <- Uhats$U1[,1]
	U2hat <- Uhats$U2[,1]
	S1t <- diag(1/U1hat) %*% S1 %*% diag(1/U1hat)
	S2t <- diag(1/U2hat) %*% S2 %*% diag(1/U2hat)

	# current frobenius norm
	gammaHat <- gMin
	loglikHatInit <- loglikHat <- sum(.armaPenLLdiffGGM(PsHat$Ps, PsHat$evPs, gammaHat, U1hat, U2hat, S1, S2, n1, n2, lambda))
	if (verbose){ print(paste("iter.:", 0, "; gamma:", round(gammaHat, digits=3), "; pen. loglik:", round(loglikHat, digits=3), sep=" ")) } 

	for (k in 1:nInit){
		# store previous estimate
		PsPrev <- PsHat; 
		gammaPrev <- gammaHat; 
		loglikIteration <- loglikPrev <- loglikHat; 
		U1prev <- U1hat; 
		U2prev <- U2hat;

		# estimate gamma
		gammaHat <- .estGamma(PsHat$Ps, S2t, gMin)
		loglikHat <- sum(.armaPenLLdiffGGM(PsHat$Ps, PsHat$evPs, gammaHat, U1hat, U2hat, S1, S2, n1, n2, lambda))

		# estimate scaled precision
		PsHat <- .armaEstPsUnstructured(S1t, S2t, p1, p2, gammaHat, log(exp(lambda) + .1 * max(0, 1 / sqrt(k) - 1/2)))

		# estimate U's
		Uhats <- .armaEstUs(PsHat$Ps, S1, S2, n1, n2, gammaHat, Uequal=Uequal)
		optTheta <- .armaPenLLdiffGGMevalUs(c(0:nStepsU)/nStepsU, PsHat$Ps, PsHat$evPs, gammaHat, U1hat, U2hat, Uhats$U1[,1], Uhats$U2[,1], S1,S2, n1, n2, lambda) 
		U1hat <- optTheta$theta1 * U1hat + (1-optTheta$theta1) * Uhats$U1[,1]
		U2hat <- optTheta$theta2 * U2hat + (1-optTheta$theta2) * Uhats$U2[,1]
		loglikHat <- optTheta$penLL1 + optTheta$penLL2

		# redefine S1tilde and S2tilde
		S1t <- diag(1/U1hat) %*% S1 %*% diag(1/U1hat)
		S2t <- diag(1/U2hat) %*% S2 %*% diag(1/U2hat)
		
		# calculate loglikelihood
		loglikHat <- sum(.armaPenLLdiffGGM(PsHat$Ps, PsHat$evPs, gammaHat, U1hat, U2hat, S1, S2, n1, n2, lambda))

		if (verbose){ print(paste("iter.:", k, "; gamma:", round(gammaHat, digits=3), "; pen. loglik:", round(loglikHat, digits=3), sep=" ")) } 
		if (((abs(loglikHat - loglikIteration) / abs(loglikIteration)) < llDiff) | (loglikHat < loglikIteration)){ break }
	}
	
	# return stuff
	return(list(Ps=PsHat$Ps, gamma=gammaHat, U1=U1hat, U2=U2hat, penLL=loglikHat, penLLinit=loglikHatInit, lambda=lambda)) 
}


