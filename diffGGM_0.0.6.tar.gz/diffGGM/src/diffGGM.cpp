// We only include RcppArmadillo.h which pulls Rcpp.h in for us
# include <RcppArmadillo.h>

// These are not needed:
// using namespace Rcpp;
// using namespace RcppArmadillo;
// [[Rcpp::depends("Rcpp")]]
// [[Rcpp::depends("RcppArmadillo")]]


// [[Rcpp::export(".armaPenLLdiffGGMevalUs")]]
Rcpp::List armaPenLLdiffGGMevalUs(arma::vec theta, const arma::mat Ps, arma::vec evPs, const double gamma, const arma::vec U1old, const arma::vec U2old,  const arma::vec U1new, const arma::vec U2new, arma::mat S1, arma::mat S2, int n1, int n2, const double lambda){ 
	/////////////////////////////////////////////////////////////////////////////////////////	
	// calculate penalized loglikelihood of differential GGM  
	/////////////////////////////////////////////////////////////////////////////////////////
	
	// calculate loglikelihood	
	int p = Ps.n_rows;

	double penLL1part1 = n1 * (1 + lambda) * sum(log(evPs)) - lambda * n1 * sum(evPs);
	double penLL2part1 = n2 * (1 + lambda) * sum(log((1-gamma) * evPs + gamma)) - lambda * n2 * sum((1-gamma) * evPs + gamma);
	
	arma::vec penLL1(theta.n_elem);
	arma::vec penLL2(theta.n_elem);

	for (int i = 0; i < theta.n_elem; ++i){
		penLL1(i) = penLL1part1 - 2 * n1 * sum(log(theta(i) * U1old + (1-theta(i)) * U1new)) - 
			n1 * sum(arma::diagvec(arma::diagmat(1/(theta(i) * U1old + 
			(1-theta(i)) * U1new)) * arma::symmatl(S1) * arma::diagmat(1/(theta(i) * U1old + (1-theta(i)) * U1new)) * arma::symmatl(Ps)));
                    
		penLL2(i) = penLL2part1 - 2 * n2 * sum(log(theta(i) * U2old + (1-theta(i)) * U2new)) -
			n2 * sum(arma::diagvec((arma::diagmat(1/(theta(i) * U2old + 
			(1-theta(i)) * U2new)) * arma::symmatl(S2) * arma::diagmat(1/(theta(i) * U2old + (1-theta(i)) * U2new))) * arma::symmatl((1-gamma) * Ps + gamma * arma::eye(p, p))));
	}               
	arma::uword index1;
	arma::uword index2;
	double maxPenLL1 = penLL1.max(index1);
	double maxPenLL2 = penLL2.max(index2);
	return Rcpp::List::create(Rcpp::Named("theta1")=theta(index1), Rcpp::Named("penLL1")=maxPenLL1, Rcpp::Named("theta2")=theta(index2), Rcpp::Named("penLL2")=maxPenLL2); 
}


// [[Rcpp::export(".armaPenLLdiffGGMevalPs")]]
Rcpp::List armaPenLLdiffGGMevalPs(arma::vec theta, const arma::mat PsOld, const arma::mat PsNew, arma::vec evPsOld, arma::vec evPsNew, const double gamma, const arma::vec U1, const arma::vec U2, arma::mat S1, arma::mat S2, int n1, int n2, const double lambda){ 
	/////////////////////////////////////////////////////////////////////////////////////////	
	// calculate penalized loglikelihood of differential GGM  
	/////////////////////////////////////////////////////////////////////////////////////////

	// calculate loglikelihood	
	int p = PsOld.n_rows;

	S1 = arma::diagmat(1/U1) * S1 * arma::diagmat(1/U1);
	S2 = arma::diagmat(1/U2) * S2 * arma::diagmat(1/U2);
	double penLL1part1 = - 2 * n1 * sum(log(U1));
	double penLL2part1 = - 2 * n2 * sum(log(U2)); 
	
	double penLL1part2Aold = - n1 * sum(arma::diagvec(S1 * PsOld));
	double penLL1part2Anew = - n1 * sum(arma::diagvec(S1 * PsNew));
	double penLL2part2Aold = - n2 * (1-gamma) * sum(arma::diagvec(S2 * PsOld));
	double penLL2part2Anew = - n2 * (1-gamma) * sum(arma::diagvec(S2 * PsNew));
	double penLL2part2Bold = - n2 * gamma * sum(arma::diagvec(S2));
	double penLL2part2Bnew = - n2 * gamma * sum(arma::diagvec(S2));
	
	arma::vec penLL(theta.n_elem);
	for (int i = 0; i < theta.n_elem; ++i){
		penLL(i) = penLL1part1 + theta(i) * penLL1part2Aold + (1 - theta(i)) * penLL1part2Anew + n1 * (1 + lambda) * sum(log(theta(i) * evPsOld + (1-theta(i)) * evPsNew)) - 
			lambda * n1 * theta(i) * sum(evPsOld) - lambda * n1 * (1 - theta(i)) * sum(evPsNew) +
			penLL2part1 + theta(i) * penLL2part2Aold + (1 - theta(i)) * penLL2part2Anew + theta(i) * penLL2part2Bold + (1 - theta(i)) * penLL2part2Bnew +
			n2 * sum(log((1-gamma) * (theta(i) * evPsOld + (1-theta(i)) * evPsNew) + gamma)) +        
			n1 * lambda * sum(log(theta(i) * evPsOld + (1-theta(i)) * evPsNew)) - lambda * n1 * theta(i) * sum(evPsOld) - lambda * n1 *  (1 - theta(i)) * sum(evPsNew);
	}               
	arma::uword index;
	double maxPenLL = penLL.max(index);
	return Rcpp::List::create(Rcpp::Named("theta")=theta(index), Rcpp::Named("penLL")=maxPenLL); 
}


// [[Rcpp::export(".armaEstUs")]]
Rcpp::List armaEstUs(arma::mat Ps, const arma::mat S1, const arma::mat S2, const double n1, const double n2, const double gamma, bool Uequal){
	/////////////////////////////////////////////////////////////////////////////////////////	
	// estimate parameters U1 and U2 (closely related to the vectors of marginal variances)
	/////////////////////////////////////////////////////////////////////////////////////////	

	// to-be-estimated parameter vectors 
	arma::vec U1;
	arma::vec U2;

	// first case: 
	if (Uequal){
		// import the FG-algorithm from the R-package JADE
		Rcpp::Environment stats("package:JADE");
		// Rcpp::Function FG = stats["FG"];
		Rcpp::Function rjd = stats["rjd"];
		Rcpp::List FGres;

		// sample proportions
		double p1 = n1 / (n1 + n2);
		double p2 = n2 / (n1 + n2);

		// eigen decomposition of Ps
		arma::vec eigvalPs;
		arma::mat eigvecPs;
		arma::eig_sym(eigvalPs, eigvecPs, arma::symmatl(Ps), "dc");
		eigvalPs = (1-0.0001) * eigvalPs + 0.0001;
        
		// matrices needed
		arma::mat A = arma::diagmat(1/sqrt(eigvalPs)) * arma::trans(eigvecPs) * (p1 * S1 + p2 * (1-gamma) * S2) * eigvecPs * arma::diagmat(1/sqrt(eigvalPs));
		arma::mat B = p2 * gamma * arma::diagmat(1/sqrt(eigvalPs)) * arma::trans(eigvecPs) * S2 * eigvecPs * arma::diagmat(1/sqrt(eigvalPs));
		arma::mat C = arma::diagmat(1/eigvalPs);
		// arma::mat Z = arma::diagmat(1/sqrt(eigvalPs)) * arma::trans(eigvecPs) * arma::diagmat(sqrt((arma::diagvec(S1) + arma::diagvec(S2))/2)) * eigvecPs * arma::diagmat(1/sqrt(eigvalPs));
		arma::mat Z = arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs) * arma::diagmat(1/sqrt((arma::diagvec(S1) + arma::diagvec(S2))/2)) * eigvecPs * arma::diagmat(sqrt(eigvalPs));

		// stack matrices A, B, C, Z
		arma::mat ABCZ = arma::zeros(4 * Ps.n_rows, Ps.n_rows);
		ABCZ(arma::span(0, Ps.n_rows-1), arma::span(0, Ps.n_rows-1)) = A;
		ABCZ(arma::span(Ps.n_rows, 2*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)) = B;
		ABCZ(arma::span(2*Ps.n_rows, 3*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)) = C;
		ABCZ(arma::span(3*Ps.n_rows, 4*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)) = Z;

		// Newton's method
		double Eerror = 10000;
		double EerrorPrev = Eerror + 1;
		int ii = 0;
		arma::mat E;
		while(ii < 100 && Eerror > 0.001 && Eerror < EerrorPrev){
		// while(ii < 1000 && Eerror > 0.0001){
			ii = ii + 1;
			EerrorPrev = Eerror;
			double eps = 0.001;
			double maxiter = 1000;
			// FGres = FG(Rcpp::Named("X", ABCZ), eps=eps, maxiter=maxiter);
			FGres = rjd(Rcpp::Named("X", ABCZ), eps=eps, maxiter=maxiter);
			arma::mat svdV = FGres[0];
			arma::mat svdD = FGres[1];
			arma::vec Da = arma::diagvec(svdD(arma::span(0, Ps.n_rows-1), arma::span(0, Ps.n_rows-1)));
			arma::vec Db = arma::diagvec(svdD(arma::span(Ps.n_rows, 2*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)));
			arma::vec Dc = arma::diagvec(svdD(arma::span(2*Ps.n_rows, 3*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)));
			arma::vec Dz = arma::diagvec(svdD(arma::span(3*Ps.n_rows, 4*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)));            
			arma::vec De = (1/Dz - Da % Dz - Db % Dz % Dc) / (1 / (Dz % Dz) + Da + Db % Dc);
			E = svdV * arma::diagmat(De) * arma::trans(svdV);
			Z = Z + E;
			ABCZ(arma::span(3*Ps.n_rows, 4*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)) = Z;  
			Eerror = sqrt(norm(E, 2));
			// Rcpp::Rcout << "max. fout: " << max(max(abs(E))) << std::endl;
			// Rcpp::Rcout << "norm fout: " << Eerror << std::endl;
		}        
		Z = ABCZ(arma::span(3*Ps.n_rows, 4*Ps.n_rows-1), arma::span(0, Ps.n_rows-1));
		U1 = arma::diagvec(eigvecPs * arma::diagmat(sqrt(eigvalPs)) * arma::pinv(Z) * arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs));
		U2 = U1;
	}

	if (!Uequal){
		// eigen decomposition of Ps
		arma::vec eigvalPs;
		arma::mat eigvecPs;
		arma::eig_sym(eigvalPs, eigvecPs, arma::symmatl(Ps), "dc");
			
		// estimate U1
		arma::vec eigvalInner;
		arma::mat eigvecInner;
		arma::eig_sym(eigvalInner, eigvecInner, arma::symmatl(arma::diagmat(1/sqrt(eigvalPs)) * arma::trans(eigvecPs) * S1  * eigvecPs * arma::diagmat(1/sqrt(eigvalPs))), "dc");
		eigvalInner = sqrt(abs(arma::real(eigvalInner)));
		U1 = arma::real(arma::diagvec(eigvecPs * arma::diagmat(sqrt(eigvalPs)) * eigvecInner * 
		arma::diagmat(eigvalInner) * arma::trans(eigvecInner) * arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs)));

		// estimate Upsilon2
		eigvalPs = (1-gamma)*eigvalPs + gamma;
		arma::eig_sym(eigvalInner, eigvecInner, arma::symmatl(arma::diagmat(1/sqrt(eigvalPs)) * arma::trans(eigvecPs) * S2  * eigvecPs * arma::diagmat(1/sqrt(eigvalPs))), "dc");
		eigvalInner = sqrt(abs(arma::real(eigvalInner)));
		U2 = arma::real(arma::diagvec(eigvecPs * arma::diagmat(sqrt(eigvalPs)) * eigvecInner * arma::diagmat(eigvalInner) * arma::trans(eigvecInner) * 
		arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs)));
	}
        
	// return estimates
	return Rcpp::List::create(Rcpp::Named("U1")=U1, Rcpp::Named("U2")=U2);
}


// [[Rcpp::export(".armaGammaEstEquation")]]
const double armaGammaEstEquation(const double x, const arma::mat Ps, const arma::mat S2t){ 
	/////////////////////////////////////////////////////////////////////////////////////////	
	// estimating equation for gamma (the dilution parameter) 
	/////////////////////////////////////////////////////////////////////////////////////////	

	// estimating equation
	int p = Ps.n_rows;
	const arma::mat Psmix = (1-x) * arma::symmatl(Ps) + x *  arma::eye(p, p);
	const double gammaDeriv = sum(arma::diagvec(arma::inv(Psmix) * (arma::symmatl(Ps) -  arma::eye(p, p)))) - sum(arma::diagvec(arma::symmatl(S2t) * (arma::symmatl(Ps) - arma::eye(p, p))));
	return gammaDeriv;
}    


// [[Rcpp::export(".armaEstPsUnstructured")]]
Rcpp::List armaEstPsUnstructured(const arma::mat S1t, const arma::mat S2t, const double p1, const double p2, const double gamma, const double lambda){	
	/////////////////////////////////////////////////////////////////////////////////////////
	// estimate the partial correlation matrix under various assumptions on its structure
	/////////////////////////////////////////////////////////////////////////////////////////

	// evaluate the estimate of the standardized precision matrix
	arma::vec eigval;
	arma::mat eigvec;
	arma::eig_sym(eigval, eigvec, arma::symmatl(p1 * S1t + p2 * (1-gamma) * S2t), "dc");
	eigval = eigval + lambda;
	arma::vec Da = (1 + lambda) * (1-gamma) - gamma * (eigval + lambda);
	Da = 2 * gamma * (p1 + lambda) / (sqrt(Da % Da + 4 * (p1 + lambda) * gamma * (1-gamma) * (eigval + lambda)) - Da);		
	arma::mat Ps = eigvec * arma::diagmat(Da) * trans(eigvec);
	
	// rescale to obtain a standardized precision matrix (as the operation on the eigenvalues need not ensure a unit diagonal)
	Ps = arma::diagmat(1/sqrt(arma::diagvec(Ps))) * Ps * arma::diagmat(1/sqrt(arma::diagvec(Ps)));

	// return the eigen-decomposition of the standardized precision matrix
	arma::eig_sym(eigval, eigvec, Ps, "dc");
	return Rcpp::List::create(Rcpp::Named("Ps")=Ps, Rcpp::Named("evPs")=eigval);
}


// [[Rcpp::export(".armaPenLLdiffGGM")]]
arma::vec armaPenLLdiffGGM(const arma::mat Ps, arma::vec evPs, const double gamma, const arma::vec U1, const arma::vec U2, const arma::mat S1, const arma::mat S2, int n1, int n2, const double lambda){ 
	/////////////////////////////////////////////////////////////////////////////////////////	
	// calculate penalized loglikelihood of differential GGM  
	/////////////////////////////////////////////////////////////////////////////////////////

	// calculate loglikelihood	
	int p = Ps.n_rows;
	arma::vec penLLs(2);
	penLLs(0) = n1 * sum(log(evPs)) - n1 * arma::accu((arma::diagmat(1/U1) * arma::symmatl(S1) * arma::diagmat(1/U1)) % Ps) - 2 * n1 * sum(log(U1)) + lambda * n1 * (sum(log(evPs)) - sum(evPs));
	penLLs(1) = n2 * sum(log((1-gamma) * evPs + gamma)) -  2 * n2 * sum(log(U2)) + lambda * n2 * (sum(log(evPs)) - sum(evPs))-
                n2 * arma::accu((arma::diagmat(1/U2) * arma::symmatl(S2) * arma::diagmat(1/U2)) % ((1-gamma) * Ps + gamma * arma::eye(p, p)));
	return penLLs; 
}


// [[Rcpp::export(".armaDiffGGMnull")]]
Rcpp::List armaDiffGGMnull(const arma::mat S1, const arma::mat S2, const double n1, const double n2, const double lambda, double llDiff, int nInit, int nStepsU){

	// set initial penalized loglikelihood
	double loglikHat = -10^10;
	double loglikHatPrev = loglikHat - 1;

	// sample proportions
	double p1 = n1 / (n1 + n2);
	double p2 = n2 / (n1 + n2);

	// initiate U
	arma::vec U = (p1 * arma::diagvec(S1) + p2 * arma::diagvec(S2));

	// declare variable outside the while-loop
	arma::mat PsHat;
	arma::vec eigvalPs;
	arma::mat eigvecPs;
	int ii = 0;    

	while(ii < nInit && loglikHat > loglikHatPrev){
		// update counter
		ii = ii+1;
		double loglikHatPrev = loglikHat;

		// re-estimate standardized precision
		arma::mat St = (arma::diagmat(1/U) * ((p1 / (1+lambda)) * S1 + (p2 / (1+lambda)) * S2) * arma::diagmat(1/U));
		St.diag() += lambda / (1+lambda);
		PsHat = arma::inv_sympd(St);

		// rescale to obtain a standardized precision matrix (as the operation on the eigenvalues need not ensure a unit diagonal)
		PsHat = arma::diagmat(1/sqrt(arma::diagvec(PsHat))) * PsHat * arma::diagmat(1/sqrt(arma::diagvec(PsHat)));

		// eigen decomposition of Ps
		arma::eig_sym(eigvalPs, eigvecPs, arma::symmatl(PsHat), "dc");
			
		// estimate U
		arma::vec eigvalInner;
		arma::mat eigvecInner;
		arma::eig_sym(eigvalInner, eigvecInner, arma::symmatl(arma::diagmat(1/sqrt(eigvalPs)) * arma::trans(eigvecPs) * 
				(p1 * S1 + p2 * S2)  * eigvecPs * arma::diagmat(1/sqrt(eigvalPs))), "dc");
		eigvalInner = sqrt(abs(arma::real(eigvalInner)));
		arma::vec Uslh = arma::real(arma::diagvec(eigvecPs * arma::diagmat(sqrt(eigvalPs)) * eigvecInner * 
				arma::diagmat(eigvalInner) * arma::trans(eigvecInner) * arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs)));

		// evaluate penalized loglikelihood along path from original to suggested estimate of U's
		arma::mat llTemp(nStepsU+1, 1);
		for (int i = 0; i < nStepsU+1; ++i){
			llTemp(i,0) = sum(armaPenLLdiffGGM(PsHat, eigvalPs, 0, (i/nStepsU) * Uslh + (1-i/nStepsU) * U, U, S1, S2, n1, n2, lambda)) + 
					sum(armaPenLLdiffGGM(PsHat, eigvalPs, 0, U, (i/nStepsU) * Uslh + (1-i/nStepsU) * U, S1, S2, n1, n2, lambda));
		} 

		// find maximum and update estimate
		double theta = 0;
		for (int i = 1; i < nStepsU+1; ++i){
			if (llTemp(i,0) > llTemp(i-1,0)){ theta = i / nStepsU; }
		}
		U = theta * Uslh + (1-theta) * U; 

		// reevaluate penalized loglikelihood
		loglikHat = sum(armaPenLLdiffGGM(PsHat, eigvalPs, 0, U, U, S1, S2, n1, n2, lambda));
	}

	return Rcpp::List::create(Rcpp::Named("Ps")=PsHat, Rcpp::Named("evPs")=eigvalPs, Rcpp::Named("U")=U, Rcpp::Named("penLL")=loglikHat);
}


// [[Rcpp::export(".cvlDiffGGMnull")]]
double cvlDiffGGMnull(const double lambda, const arma::mat Y1, const arma::mat Y2, const double llDiff, int nInit, int nStepsU){
	int n1 = Y1.n_rows;
	int n2 = Y2.n_rows;  
	Rcpp::IntegerVector rowID; 
	arma::vec slh(n1 + n2);
	arma::mat S1 = arma::cov(Y1, 1);
	arma::mat S2 = arma::cov(Y2, 1);
	for (int i = 0;  i < n1; ++i){
		rowID = Rcpp::seq_len(n1) - 1;
		rowID = rowID[rowID != i];
		S1 = arma::cov(Y1.rows(Rcpp::as<arma::uvec>(rowID)), 1);
		Rcpp::List MLres = armaDiffGGMnull(S1, S2, n1-1, n2, lambda, llDiff, nInit, nStepsU);
		slh(i) = sum(armaPenLLdiffGGM(Rcpp::as<arma::mat>(MLres[0]), Rcpp::as<arma::vec>(MLres[1]), 0.0, Rcpp::as<arma::vec>(MLres[2]), Rcpp::as<arma::vec>(MLres[2]), S1, S2, n1-1, n2, 0.0));
	}
	S1 = arma::cov(Y1, 1);
	for (int i = 0; i < n2; ++i){
		rowID = Rcpp::seq_len(n2) - 1;
		rowID = rowID[rowID != i];
		S2 = arma::cov(Y2.rows(Rcpp::as<arma::uvec>(rowID)), 1);
		Rcpp::List MLres = armaDiffGGMnull(S1, S2, n1, n2-1, lambda, llDiff, nInit, nStepsU);
		slh(i+n1) = sum(armaPenLLdiffGGM(Rcpp::as<arma::mat>(MLres[0]), Rcpp::as<arma::vec>(MLres[1]), 0.0, Rcpp::as<arma::vec>(MLres[2]), Rcpp::as<arma::vec>(MLres[2]), S1, S2, n1, n2-1, 0.0));
	}
	return -mean(slh);
}


/*

// [[Rcpp::export(".armaEstUs2")]]
Rcpp::List armaEstUs2(arma::mat Ps, const arma::mat S1, const arma::mat S2, const double n1, const double n2, const double gamma, bool Uequal){
	/////////////////////////////////////////////////////////////////////////////////////////	
	// estimate parameters U1 and U2 (closely related to the vectors of marginal variances)
	/////////////////////////////////////////////////////////////////////////////////////////	

	// to-be-estimated parameter vectors 
	arma::vec U1;
	arma::vec U2;

	// first case: 
	if (Uequal){
		// import the FG-algorithm from the R-package JADE
		Rcpp::Environment stats("package:JADE");
		Rcpp::Function FG = stats["FG"];
		Rcpp::Function rjd = stats["rjd"];
		Rcpp::List FGres;

		// sample proportions
		double p1 = n1 / (n1 + n2);
		double p2 = n2 / (n1 + n2);

		// eigen decomposition of Ps
		arma::vec eigvalPs;
		arma::mat eigvecPs;
		arma::eig_sym(eigvalPs, eigvecPs, arma::symmatl(Ps), "dc");
		eigvalPs = (1-0.0001) * eigvalPs + 0.0001;
        
		// matrices needed
		arma::mat A = arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs) * (p1 * S1 + p2 * (1-gamma) * S2) * eigvecPs * arma::diagmat(sqrt(eigvalPs));
		arma::mat B = p2 * arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs) * S2 * eigvecPs * arma::diagmat(sqrt(eigvalPs));
		arma::mat C = arma::diagmat(eigvalPs);
	    
		// initiate Z
		arma::vec eigvalInner;
		arma::mat eigvecInner;
		arma::eig_sym(eigvalInner, eigvecInner, arma::diagmat(1/sqrt(eigvalPs)) * arma::trans(eigvecPs) * S1  * eigvecPs * arma::diagmat(1/sqrt(eigvalPs)), "dc");
		eigvalInner = sqrt(abs(arma::real(eigvalInner)));
		eigvalPs = (1-gamma)*eigvalPs + gamma;
		arma::eig_sym(eigvalInner, eigvecInner, arma::diagmat(1/sqrt(eigvalPs)) * arma::trans(eigvecPs) * S2  * eigvecPs * arma::diagmat(1/sqrt(eigvalPs)), "dc");
		eigvalInner = sqrt(abs(arma::real(eigvalInner)));
		arma::mat Z = eigvecPs * arma::diagmat(sqrt(eigvalPs)) * eigvecInner * arma::diagmat(eigvalInner) * arma::trans(eigvecInner) * arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs);
		Z = p2 *Z + p1 *eigvecPs * arma::diagmat(sqrt(eigvalPs)) * eigvecInner * arma::diagmat(eigvalInner) * arma::trans(eigvecInner) * arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs);
	    
		// stack matrices A, B, C, Z
		arma::mat ABCZ = arma::zeros(4 * Ps.n_rows, Ps.n_rows);
		ABCZ(arma::span(0, Ps.n_rows-1), arma::span(0, Ps.n_rows-1)) = A;
		ABCZ(arma::span(Ps.n_rows, 2*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)) = B;
		ABCZ(arma::span(2*Ps.n_rows, 3*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)) = C;
		ABCZ(arma::span(3*Ps.n_rows, 4*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)) = Z;

		// Newton's method
		double Eerror = 10000;
		double EerrorPrev = Eerror + 1;
		int ii = 0;
		while(ii < 10 && Eerror > 0.1 && Eerror < EerrorPrev){
			ii = ii + 1;
			EerrorPrev = Eerror;
			double eps = 0.1;
			double maxiter = 10000;
			// FGres = FG(Rcpp::Named("X", ABCZ), eps=eps, maxiter=maxiter);
			FGres = rjd(Rcpp::Named("X", ABCZ), eps=eps, maxiter=maxiter);

			// format stuff for the use of the rjd function directly in C++
			//double X = arma::vectorise(ABCZ);
			arma::ivec kpmaxit(3);
			kpmaxit[0] = 4; kpmaxit[1] = Ps.n_rows; kpmaxit[2] = 10000;
			arma::ivec kpMaxitSLH = arma::conv_to< arma::ivec >::from(kpmaxit);
			int kpMaxit = arma::conv_to<int>::from(kpMaxitSLH);  

			// int kpMaxit = 4 | Ps.n_rows | 10000;

			// double mWeights;
			arma::vec mWeights(4);
			mWeights[0] = (double) 1; mWeights[1] = (double) 1; mWeights[2] = (double) 1; mWeights[3] = (double) 1;
			double w = arma::conv_to<double>::from(mWeights);  
			// double mWeights[4];
			// mWeights[0] = (double) 1; mWeights[1] = (double) 1; mWeights[2] = (double) 1; mWeights[3] = (double) 1;

			// double w = reinterpret_cast<double>(mWeights); 
			int p = (int) Ps.n_rows; 
			double result = static_cast<double>(p^2 + 1);
 
// std::vector<double> z = conv_to< std::vector<double> >::from(arma::vectorise(ABCZ)); 

//   res <- .C("rjdc", as.double(as.vector(X)), as.integer(c(K, 
//        p, maxiter)), as.double(as.vector(weight)), as.double(eps), 
//       res = double(p^2 + 1), PACKAGE = "JADE")$res
//
	// X=ABCZ
	// results ????
//			arma::vec Y = rjdc(arma::vectorise(ABCZ)
double X = arma::conv_to<double>::from(arma::vectorise(ABCZ)); 
// double X = &X;
// double rjdc(X, kpMaxit, w, eps, result);

// vec y = zeros<vec>(10);
			arma::mat svdV = FGres[0];
			arma::mat svdD = FGres[1];
			arma::vec Da = arma::diagvec(svdD(arma::span(0, Ps.n_rows-1), arma::span(0, Ps.n_rows-1)));
			arma::vec Db = arma::diagvec(svdD(arma::span(Ps.n_rows, 2*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)));
			arma::vec Dc = arma::diagvec(svdD(arma::span(2*Ps.n_rows, 3*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)));
			arma::vec Dz = arma::diagvec(svdD(arma::span(3*Ps.n_rows, 4*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)));            
			arma::vec De = (1/Dz - Da % Dz - Db % Dz % Dc) / (1 / (Dz % Dz) + Da + Db % Dc);
			arma::mat E = svdV * arma::diagmat(De) * arma::trans(svdV);
			ABCZ(arma::span(3*Ps.n_rows, 4*Ps.n_rows-1), arma::span(0, Ps.n_rows-1)) = Z + E;  
			Eerror = sqrt(norm(E, 2));
		}        
		Z = ABCZ(arma::span(3*Ps.n_rows, 4*Ps.n_rows-1), arma::span(0, Ps.n_rows-1));
		U1 = arma::diagvec(eigvecPs * arma::diagmat(sqrt(eigvalPs)) * arma::pinv(Z) * arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs));
		U2 = U1;
	}

	if (!Uequal){
		// eigen decomposition of Ps
		arma::vec eigvalPs;
		arma::mat eigvecPs;
		arma::eig_sym(eigvalPs, eigvecPs, arma::symmatl(Ps), "dc");
			
		// estimate U1
		arma::vec eigvalInner;
		arma::mat eigvecInner;
		arma::eig_sym(eigvalInner, eigvecInner, arma::symmatl(arma::diagmat(1/sqrt(eigvalPs)) * arma::trans(eigvecPs) * S1  * eigvecPs * arma::diagmat(1/sqrt(eigvalPs))), "dc");
		eigvalInner = sqrt(abs(arma::real(eigvalInner)));
		U1 = arma::real(arma::diagvec(eigvecPs * arma::diagmat(sqrt(eigvalPs)) * eigvecInner * 
		arma::diagmat(eigvalInner) * arma::trans(eigvecInner) * arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs)));

		// estimate Upsilon2
		eigvalPs = (1-gamma)*eigvalPs + gamma;
		arma::eig_sym(eigvalInner, eigvecInner, arma::symmatl(arma::diagmat(1/sqrt(eigvalPs)) * arma::trans(eigvecPs) * S2  * eigvecPs * arma::diagmat(1/sqrt(eigvalPs))), "dc");
		eigvalInner = sqrt(abs(arma::real(eigvalInner)));
		U2 = arma::real(arma::diagvec(eigvecPs * arma::diagmat(sqrt(eigvalPs)) * eigvecInner * arma::diagmat(eigvalInner) * arma::trans(eigvecInner) * 
		arma::diagmat(sqrt(eigvalPs)) * arma::trans(eigvecPs)));
	}
        
	// return estimates
	return Rcpp::List::create(Rcpp::Named("U1")=U1, Rcpp::Named("U2")=U2);
}


double **prepmat(double *X, int n, int k){
	/////////////////////////////////////////////////////////////////////////////////////////	
	// code directly from the R-package 'JADE'
	// authors: 
	// their code only included as their C++ workhorse function could not directly be called.
	/////////////////////////////////////////////////////////////////////////////////////////

	int i;
	int j;
	double **Y = new double* [n];
	for (i=0; i<n; i++){ Y[i]=new double [k]; }
	for (i=0; i<n; i++){ 
		for (j=0;j<k; j++){
			Y[i][j]=X[j*n+i];
		}
	}
	return Y;
}

double **mult(double **X, double **Y, int p){
	/////////////////////////////////////////////////////////////////////////////////////////	
	// code directly from the R-package 'JADE'
	// authors: 
	// their code only included as their C++ workhorse function could not directly be called.
	/////////////////////////////////////////////////////////////////////////////////////////

	int i;
	int j;
	int k;
	double **Z1 = new double* [p];
	for (i=0; i<p; i++){ Z1[i] = new double [p]; }
	double **Z = new double* [p];
	for (i=0; i<p; i++){ Z[i] = new double [p]; }
	for (i=0; i<p; i++){ 
		for (j=0; j<p; j++){
			Z1[i][j] = 0;
			for (k=0; k<p; k++){
				Z1[i][j] += Y[k][i]*X[k][j]; 
			}
		}  
	}
	for (i=0; i<p; i++){ 
		for (j=0; j<(i+1); j++){
			Z[i][j]=0;
			for (k=0; k<p; k++){     
				Z[i][j] += Z1[i][k]*Y[k][j];
			} 
			Z[j][i] = Z[i][j];
		}  
	}
	return Z;
}


void rjdc(double *X, int *kpmaxit, double *w, double *eps, double *result){
	/////////////////////////////////////////////////////////////////////////////////////////	
	// code directly from the R-package 'JADE'
	// authors: 
	// their code only included as their C++ workhorse function could not directly be called.
	/////////////////////////////////////////////////////////////////////////////////////////

	int K = kpmaxit[0]; 
	int p = kpmaxit[1];
	int maxiter = kpmaxit[2]; 
	int i;
	int j;
	int k;
	int l;
	double iter = 0;
	double alpha;
	double beta; 
	double a1;
	double b1; 
	double a2;
	double b2; 
	double u;
	double c;
	double si;
	double co;
	double theta;     
	bool cc = 1;
	double **A = prepmat(X,K*p,p);  
	double **B = new double* [p];
	for (i=0; i<p; i++){
		B[i]=new double [p];
	}
	for (i=0; i<(p-1); i++){
		B[i][i] = 1;
		for (j=(i+1); j<p; j++){ 
			B[i][j] = 0;
			B[j][i] = 0;
		}
	}
	B[p-1][p-1] = 1; 
    
	while(cc){ 
		iter++;
		if(iter>maxiter){
			B[0][0] = 2;   
			break;
		} 
		cc = 0;
		for(i=0; i<(p-1); i++){
			for(j=(i+1); j<p; j++){
				alpha = 0;
				beta = 0;
				for(k=0; k<K; k++){
					u = A[k*p+i][i]-A[k*p+j][j];
					c = A[k*p+i][j];
					alpha += w[k]*(u*u-4*c*c);
					beta += w[k]*4*u*c; 
				}
				theta = atan(beta/(alpha+sqrt(alpha*alpha+beta*beta)))/2;
				si = sin(theta);
				co = cos(theta);
				if(abs(si)>eps[0]){ cc = 1; }
				for(l=0; l<p; l++){
					b1 = B[i][l];
					b2 = B[j][l];
					B[i][l] = co*b1+si*b2;
					B[j][l] = co*b2-si*b1;
				}
				for(k=0; k<K; k++){
					for(l=0; l<p; l++){
						a1 = A[k*p+i][l];
						a2 = A[k*p+j][l];
						A[k*p+i][l] = co*a1+si*a2;
						A[k*p+j][l] = co*a2-si*a1;
					}
					for(l=0; l<p; l++){
						a1 = A[k*p+l][i];
						a2 = A[k*p+l][j];
						A[k*p+l][i] = co*a1+si*a2;
						A[k*p+l][j] = co*a2-si*a1;
					}
				}
			}
		}
	}

	l=0;
	for(i=0; i<p; i++){   
		for(j=0; j<p; j++){
			result[l] = B[i][j];
			l++;
		}
	}
	result[p*p] = iter;
 
	for(i=0; i<(K*p); i++){
		delete [] A[i]; 
	}
	delete [] A;
  
	for(i=0; i<p; i++){
		delete [] B[i];
	}
	delete [] B;
}



*/
